#include <stdio.h>

int main(){
       printf("hello guys");
       return 0;
	   }